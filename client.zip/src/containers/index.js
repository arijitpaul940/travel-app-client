export { default as HomePage } from "./HomePage/HomePage";
export { default as VisitedPlacesPage } from "./VisitedPlacesPage/VisitedPlacesPage";
export { default as RecommendedPlacesPage } from "./RecommendedPlacesPage/RecommendedPlacesPage";
export { default as NotFoundPage } from "./NotFoundPage/NotFoundPage";
